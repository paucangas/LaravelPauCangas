<?php $__env->startSection('content'); ?>
    <h1><?php echo e($video->title); ?></h1>
    <p><?php echo e($video->description); ?></p>
    <video src="<?php echo e($video->url); ?>" controls></video>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.videos-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alumne/Escriptori/LaravelPauCangas/LaravelProject/VideosAppPau/resources/views/videos/show.blade.php ENDPATH**/ ?>
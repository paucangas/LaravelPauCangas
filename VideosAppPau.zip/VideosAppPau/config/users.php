<?php

return [
    'default' => [
        'name' => 'Default User',
        'email' => 'default@example.com',
        'password' => 'default_password',
    ],
    'professor' => [
        'name' => 'Professor User',
        'email' => 'professor@example.com',
        'password' => 'professor_password',
    ],
];
